# SMART Tutorial

Run the tutorial here:
https://cerner.github.io/smart-on-fhir-tutorial

Description
------------
The SMART tutorial is intended to help developers quickly create an example smart app, register it with Cerner's code console, and test it against Cerner's sandbox. It is a [Slate](https://github.com/lord/slate) site hosted through GitHub Pages and includes a small example app in the source folder.

Getting Started
------------------------------

### Prerequisites

You're going to need:

 - GitHub account
